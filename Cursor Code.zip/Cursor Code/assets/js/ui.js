/**
 * ui.js
 * Small DOM helpers + reusable product card rendering.
 */

(function () {
  "use strict";

  function $(sel, root) {
    return (root || document).querySelector(sel);
  }

  function escapeHtml(s) {
    return String(s)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function sizePickerHtml(productId) {
    const sizes = ["S", "M", "L", "XL"];
    return `
      <div class="sizes" role="group" aria-label="Choose size">
        ${sizes
          .map(
            (s, i) => `
            <button class="size-btn" type="button"
              data-size="${s}" data-product="${escapeHtml(productId)}"
              aria-pressed="${i === 0 ? "true" : "false"}">${s}</button>
          `
          )
          .join("")}
      </div>
    `;
  }

  function selectedSize(root) {
    const pressed = root.querySelector('.size-btn[aria-pressed="true"]');
    return pressed ? pressed.getAttribute("data-size") : "M";
  }

  function wireSizeButtons(root) {
    root.querySelectorAll(".size-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const group = btn.closest(".sizes");
        if (!group) return;
        group.querySelectorAll(".size-btn").forEach((b) =>
          b.setAttribute("aria-pressed", "false")
        );
        btn.setAttribute("aria-pressed", "true");
      });
    });
  }

  function productCardHtml(p) {
    const href = "product.html?id=" + encodeURIComponent(p.id);
    return `
      <article class="product">
        <a class="product-media" href="${href}" aria-label="${escapeHtml(p.name)}">
          <img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy" />
        </a>
        <div class="product-body">
          <div class="product-top">
            <div>
              <h3 class="product-title">${escapeHtml(p.name)}</h3>
              <div class="product-meta">${escapeHtml(p.category)} • ${escapeHtml(
      p.gender === "men" ? "Men" : "Women"
    )}</div>
            </div>
            <div class="price">${window.Store.formatMoney(p.price)}</div>
          </div>

          ${sizePickerHtml(p.id)}

          <div class="product-actions">
            <a class="btn btn-ghost" href="${href}">Details</a>
            <button class="btn btn-primary" type="button" data-add="${escapeHtml(
              p.id
            )}">
              Add to Cart
            </button>
          </div>
        </div>
      </article>
    `;
  }

  function renderProductGrid(host, products) {
    if (!host) return;
    host.innerHTML = products
      .map((p) => `<div class="col-3">${productCardHtml(p)}</div>`)
      .join("");

    // Wire size pickers
    host.querySelectorAll(".product").forEach((card) => wireSizeButtons(card));

    // Wire Add to Cart buttons
    host.querySelectorAll("[data-add]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const productId = btn.getAttribute("data-add");
        const card = btn.closest(".product");
        const size = card ? selectedSize(card) : "M";
        try {
          window.Store.addToCart(productId, size, 1);
          btn.textContent = "Added";
          setTimeout(() => (btn.textContent = "Add to Cart"), 900);
        } catch (e) {
          alert(e && e.message ? e.message : "Unable to add to cart.");
        }
      });
    });
  }

  window.UI = {
    $,
    escapeHtml,
    renderProductGrid,
  };
})();

