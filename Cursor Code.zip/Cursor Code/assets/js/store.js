/**
 * Store.js
 * - Product catalog (demo data)
 * - Cart logic backed by localStorage
 * - Small event system so UI updates without reload
 *
 * Beginner friendly: everything is plain JavaScript, no frameworks.
 */

(function () {
  "use strict";

  /** @typedef {"S"|"M"|"L"|"XL"} Size */

  const STORAGE_KEY = "mens-womens-shop.cart.v1";

  /** @type {Array<{id:string, gender:"men"|"women", category:string, name:string, price:number, image:string, images?:string[], description:string, tags:string[]}>} */
  const PRODUCTS = [
    // MEN
    {
      id: "m-oxford-shirt",
      gender: "men",
      category: "Shirts",
      name: "Classic Oxford Shirt",
      price: 39.99,
      image:
        "https://images.unsplash.com/photo-1520975958225-5a3b8a64d97b?auto=format&fit=crop&w=1200&q=80",
      description:
        "A crisp oxford shirt that works for office days and weekends. Soft cotton feel with a clean, tailored look.",
      tags: ["shirt", "oxford", "smart"],
    },
    {
      id: "m-hoodie-urban",
      gender: "men",
      category: "Hoodies",
      name: "Urban Essential Hoodie",
      price: 49.0,
      image:
        "https://images.unsplash.com/photo-1520975685586-213fbf7f2b20?auto=format&fit=crop&w=1200&q=80",
      description:
        "Warm, minimal hoodie with an everyday fit. Great for layering and travel.",
      tags: ["hoodie", "casual", "warm"],
    },
    {
      id: "m-denim-jacket",
      gender: "men",
      category: "Jackets",
      name: "Washed Denim Jacket",
      price: 79.99,
      image:
        "https://images.unsplash.com/photo-1520975911288-3dc2e1b250b6?auto=format&fit=crop&w=1200&q=80",
      description:
        "A timeless denim jacket with a modern wash. Pairs perfectly with tees and chinos.",
      tags: ["jacket", "denim", "layer"],
    },
    {
      id: "m-chino-pants",
      gender: "men",
      category: "Pants",
      name: "Slim Chino Pants",
      price: 44.5,
      image:
        "https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=1200&q=80",
      description:
        "Comfort stretch chinos with a clean slim silhouette. Easy to dress up or down.",
      tags: ["pants", "chino", "slim"],
    },
    {
      id: "m-running-shoes",
      gender: "men",
      category: "Shoes",
      name: "Lightweight Runner",
      price: 69.99,
      image:
        "https://images.unsplash.com/photo-1528701800489-20be3c1ea0d4?auto=format&fit=crop&w=1200&q=80",
      description:
        "Breathable everyday runners designed for comfort and long walks.",
      tags: ["shoes", "runner", "sport"],
    },
    {
      id: "m-knit-sweater",
      gender: "men",
      category: "Sweaters",
      name: "Textured Knit Sweater",
      price: 55.0,
      image:
        "https://images.unsplash.com/photo-1520974754538-38a2c11283a8?auto=format&fit=crop&w=1200&q=80",
      description:
        "Soft textured knit that elevates any outfit. Comfortable for cool evenings.",
      tags: ["sweater", "knit", "smart-casual"],
    },

    // WOMEN
    {
      id: "w-summer-dress",
      gender: "women",
      category: "Dresses",
      name: "Flowy Summer Dress",
      price: 59.99,
      image:
        "https://images.unsplash.com/photo-1520975686635-3f0c4dfb4e34?auto=format&fit=crop&w=1200&q=80",
      description:
        "Lightweight, flattering dress made for sunny days. Easy to style with sneakers or sandals.",
      tags: ["dress", "summer", "flowy"],
    },
    {
      id: "w-tailored-blazer",
      gender: "women",
      category: "Blazers",
      name: "Tailored Blazer",
      price: 89.0,
      image:
        "https://images.unsplash.com/photo-1520975958433-5ad0cb1b61bf?auto=format&fit=crop&w=1200&q=80",
      description:
        "A sharp blazer with a modern silhouette. Perfect for workwear and evenings out.",
      tags: ["blazer", "smart", "work"],
    },
    {
      id: "w-relaxed-jeans",
      gender: "women",
      category: "Jeans",
      name: "Relaxed High-Waist Jeans",
      price: 64.0,
      image:
        "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=1200&q=80",
      description:
        "Comfort-first denim with a flattering high waist. Relaxed leg for a modern look.",
      tags: ["jeans", "denim", "high-waist"],
    },
    {
      id: "w-knit-cardigan",
      gender: "women",
      category: "Knitwear",
      name: "Soft Knit Cardigan",
      price: 52.0,
      image:
        "https://images.unsplash.com/photo-1520975754174-9f40a7c4bca3?auto=format&fit=crop&w=1200&q=80",
      description:
        "Cozy cardigan for layering. Soft touch and an easy, relaxed fit.",
      tags: ["cardigan", "knit", "layer"],
    },
    {
      id: "w-sneakers-white",
      gender: "women",
      category: "Shoes",
      name: "Clean White Sneakers",
      price: 74.99,
      image:
        "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=1200&q=80",
      description:
        "Minimal sneakers that go with everything. Comfortable cushioning for everyday wear.",
      tags: ["shoes", "sneakers", "minimal"],
    },
    {
      id: "w-oversized-tee",
      gender: "women",
      category: "Tops",
      name: "Oversized Everyday Tee",
      price: 24.99,
      image:
        "https://images.unsplash.com/photo-1520975683894-3fa1c16c3e2c?auto=format&fit=crop&w=1200&q=80",
      description:
        "An easy oversized tee with soft fabric and a clean neckline. Great for casual outfits.",
      tags: ["tee", "top", "casual"],
    },
  ];

  function clamp(n, min, max) {
    return Math.max(min, Math.min(max, n));
  }

  function formatMoney(amount) {
    return "$" + Number(amount || 0).toFixed(2);
  }

  /** Cart line: { key: "productId:size", productId, size, qty } */
  function readCart() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const parsed = raw ? JSON.parse(raw) : { lines: [] };
      if (!parsed || !Array.isArray(parsed.lines)) return { lines: [] };
      return parsed;
    } catch {
      return { lines: [] };
    }
  }

  function writeCart(cart) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
    window.dispatchEvent(new CustomEvent("cart:changed", { detail: cart }));
  }

  function getProducts() {
    return PRODUCTS.slice();
  }

  function getProductById(id) {
    return PRODUCTS.find((p) => p.id === id) || null;
  }

  function getCart() {
    return readCart();
  }

  function getCartItemCount() {
    const cart = readCart();
    return cart.lines.reduce((sum, l) => sum + (l.qty || 0), 0);
  }

  function addToCart(productId, size, qty) {
    const p = getProductById(productId);
    if (!p) throw new Error("Product not found");

    /** @type {Size[]} */
    const allowed = ["S", "M", "L", "XL"];
    if (!allowed.includes(size)) throw new Error("Invalid size");

    const addQty = clamp(Number(qty || 1), 1, 99);
    const cart = readCart();
    const key = productId + ":" + size;
    const existing = cart.lines.find((l) => l.key === key);
    if (existing) {
      existing.qty = clamp((existing.qty || 0) + addQty, 1, 99);
    } else {
      cart.lines.push({ key, productId, size, qty: addQty });
    }
    writeCart(cart);
    return cart;
  }

  function setLineQty(key, qty) {
    const cart = readCart();
    const line = cart.lines.find((l) => l.key === key);
    if (!line) return cart;
    const n = clamp(Number(qty || 1), 1, 99);
    line.qty = n;
    writeCart(cart);
    return cart;
  }

  function removeLine(key) {
    const cart = readCart();
    cart.lines = cart.lines.filter((l) => l.key !== key);
    writeCart(cart);
    return cart;
  }

  function clearCart() {
    writeCart({ lines: [] });
  }

  function getCartTotals() {
    const cart = readCart();
    let subtotal = 0;
    const detailed = cart.lines
      .map((l) => {
        const p = getProductById(l.productId);
        if (!p) return null;
        const qty = clamp(Number(l.qty || 1), 1, 99);
        const lineTotal = p.price * qty;
        subtotal += lineTotal;
        return {
          key: l.key,
          product: p,
          size: l.size,
          qty,
          lineTotal,
        };
      })
      .filter(Boolean);

    // Demo shipping: free over $120, else $7.99
    const shipping = subtotal >= 120 || subtotal === 0 ? 0 : 7.99;
    // Demo tax: 8%
    const tax = subtotal * 0.08;
    const total = subtotal + shipping + tax;

    return {
      lines: detailed,
      subtotal,
      shipping,
      tax,
      total,
    };
  }

  // Expose a small API globally
  window.Store = {
    getProducts,
    getProductById,
    formatMoney,
    getCart,
    getCartItemCount,
    getCartTotals,
    addToCart,
    setLineQty,
    removeLine,
    clearCart,
  };
})();

