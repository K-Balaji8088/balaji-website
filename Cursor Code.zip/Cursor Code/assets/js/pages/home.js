/**
 * home.js
 * Renders featured products on the home page.
 */

(function () {
  "use strict";

  function pickFeatured(products, gender, count) {
    const list = products.filter((p) => p.gender === gender);
    return list.slice(0, count);
  }

  document.addEventListener("DOMContentLoaded", () => {
    const products = window.Store.getProducts();

    const menHost = document.getElementById("featuredMen");
    const womenHost = document.getElementById("featuredWomen");

    window.UI.renderProductGrid(menHost, pickFeatured(products, "men", 4));
    window.UI.renderProductGrid(womenHost, pickFeatured(products, "women", 4));
  });
})();

