/**
 * checkout.js
 * Checkout page (demo):
 * - shows order summary
 * - simple form validation
 * - "Place order" clears the cart and shows success
 */

(function () {
  "use strict";

  function escapeHtml(s) {
    return window.UI.escapeHtml(s);
  }

  function renderSummary() {
    const host = document.getElementById("checkoutSummary");
    if (!host) return;
    const totals = window.Store.getCartTotals();
    const lines = totals.lines;

    if (lines.length === 0) {
      host.innerHTML = `
        <div class="empty">
          Your cart is empty. Go back to <a class="btn" href="men.html">Men</a> or <a class="btn" href="women.html">Women</a>.
        </div>
      `;
      return;
    }

    host.innerHTML = `
      <div class="card card-pad summary">
        <h2 style="margin:0 0 8px; letter-spacing:-.02em;">Order Summary</h2>
        <div style="display:grid; gap:10px; margin-bottom:10px;">
          ${lines
            .map(
              (l) => `
            <div class="line" style="border-bottom:0; padding:8px 0;">
              <span>
                ${escapeHtml(l.product.name)} <span class="product-meta">(${escapeHtml(l.size)} × ${l.qty})</span>
              </span>
              <strong>${window.Store.formatMoney(l.lineTotal)}</strong>
            </div>
          `
            )
            .join("")}
        </div>
        <div class="line"><span>Subtotal</span><strong>${window.Store.formatMoney(totals.subtotal)}</strong></div>
        <div class="line"><span>Shipping</span><strong>${window.Store.formatMoney(totals.shipping)}</strong></div>
        <div class="line"><span>Estimated tax</span><strong>${window.Store.formatMoney(totals.tax)}</strong></div>
        <div class="total"><span>Total</span><strong>${window.Store.formatMoney(totals.total)}</strong></div>
      </div>
    `;
  }

  function wireForm() {
    const form = document.getElementById("checkoutForm");
    const status = document.getElementById("checkoutStatus");
    if (!form || !status) return;

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const totals = window.Store.getCartTotals();
      if (totals.lines.length === 0) {
        status.innerHTML = `<div class="empty">Cart is empty. Nothing to checkout.</div>`;
        return;
      }

      // Very simple validation
      const required = ["fullName", "email", "address", "city", "country", "payment"];
      for (const id of required) {
        const el = document.getElementById(id);
        if (!el || !String(el.value || "").trim()) {
          el && el.focus && el.focus();
          status.innerHTML = `<div class="empty">Please fill out all required fields.</div>`;
          return;
        }
      }

      // Demo: place order
      window.Store.clearCart();
      status.innerHTML = `
        <div class="card card-pad" style="border-color: rgba(34,197,94,.35); background: rgba(34,197,94,.08);">
          <h2 style="margin:0 0 8px;">Order placed!</h2>
          <div class="product-meta">Thanks for shopping. This demo store cleared your cart.</div>
          <div style="margin-top:12px; display:flex; gap:10px; flex-wrap:wrap;">
            <a class="btn btn-primary" href="index.html">Back to Home</a>
            <a class="btn" href="men.html">Continue shopping</a>
          </div>
        </div>
      `;
      renderSummary();
      form.reset();
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    renderSummary();
    wireForm();
  });

  window.addEventListener("cart:changed", renderSummary);
})();

