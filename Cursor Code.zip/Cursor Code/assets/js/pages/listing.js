/**
 * listing.js
 * Used by men.html and women.html
 * - search by name/category/tags
 * - filter by category
 * - filter by max price
 */

(function () {
  "use strict";

  function getPageGender() {
    // set in each page via <body data-gender="men|women">
    const g = document.body.getAttribute("data-gender");
    return g === "women" ? "women" : "men";
  }

  function getParams() {
    const sp = new URLSearchParams(location.search);
    const q = (sp.get("q") || "").trim();
    const cat = (sp.get("cat") || "").trim();
    const max = Number(sp.get("max") || "");
    return {
      q,
      cat,
      max: Number.isFinite(max) && max > 0 ? max : null,
    };
  }

  function setParams(next) {
    const sp = new URLSearchParams(location.search);
    if (next.q != null) {
      const v = String(next.q).trim();
      if (v) sp.set("q", v);
      else sp.delete("q");
    }
    if (next.cat != null) {
      const v = String(next.cat).trim();
      if (v) sp.set("cat", v);
      else sp.delete("cat");
    }
    if (next.max != null) {
      const v = Number(next.max);
      if (Number.isFinite(v) && v > 0) sp.set("max", String(v));
      else sp.delete("max");
    }
    const qs = sp.toString();
    location.search = qs ? "?" + qs : "";
  }

  function matchesQuery(p, q) {
    if (!q) return true;
    const t = q.toLowerCase();
    const hay = [p.name, p.category, (p.tags || []).join(" ")]
      .join(" ")
      .toLowerCase();
    return hay.includes(t);
  }

  function matchesCategory(p, cat) {
    if (!cat) return true;
    return p.category.toLowerCase() === cat.toLowerCase();
  }

  function matchesMax(p, max) {
    if (!max) return true;
    return p.price <= max;
  }

  function uniqueCategories(products) {
    const set = new Set(products.map((p) => p.category));
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }

  document.addEventListener("DOMContentLoaded", () => {
    const gender = getPageGender();
    const all = window.Store.getProducts().filter((p) => p.gender === gender);
    const params = getParams();

    // Populate filters
    const catSelect = document.getElementById("catSelect");
    const maxSelect = document.getElementById("maxSelect");
    const qInput = document.getElementById("pageSearch");
    const resultLabel = document.getElementById("resultLabel");
    const grid = document.getElementById("productGrid");

    if (qInput) qInput.value = params.q;

    if (catSelect) {
      catSelect.innerHTML =
        `<option value="">All categories</option>` +
        uniqueCategories(all)
          .map((c) => `<option value="${window.UI.escapeHtml(c)}">${window.UI.escapeHtml(c)}</option>`)
          .join("");
      if (params.cat) catSelect.value = params.cat;
    }

    if (maxSelect) {
      // Simple buckets
      const options = [
        { v: "", label: "Any price" },
        { v: "30", label: "Under $30" },
        { v: "50", label: "Under $50" },
        { v: "80", label: "Under $80" },
        { v: "120", label: "Under $120" },
      ];
      maxSelect.innerHTML = options
        .map((o) => `<option value="${o.v}">${o.label}</option>`)
        .join("");
      if (params.max) maxSelect.value = String(params.max);
    }

    function render() {
      const p = getParams();
      const filtered = all
        .filter((x) => matchesQuery(x, p.q))
        .filter((x) => matchesCategory(x, p.cat))
        .filter((x) => matchesMax(x, p.max));

      if (resultLabel) {
        resultLabel.textContent =
          filtered.length +
          " item" +
          (filtered.length === 1 ? "" : "s") +
          (p.q ? ` for “${p.q}”` : "");
      }

      if (filtered.length === 0) {
        grid.innerHTML = `<div class="col-12"><div class="empty">No products match your search/filters. Try clearing filters.</div></div>`;
        return;
      }

      window.UI.renderProductGrid(grid, filtered);
    }

    render();

    // Wire controls
    if (qInput) {
      qInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") setParams({ q: qInput.value });
      });
    }
    if (catSelect) catSelect.addEventListener("change", () => setParams({ cat: catSelect.value }));
    if (maxSelect) maxSelect.addEventListener("change", () => setParams({ max: maxSelect.value }));

    const clearBtn = document.getElementById("clearFilters");
    if (clearBtn) clearBtn.addEventListener("click", () => setParams({ q: "", cat: "", max: "" }));
  });
})();

