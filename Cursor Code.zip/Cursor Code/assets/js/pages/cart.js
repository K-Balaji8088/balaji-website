/**
 * cart.js
 * Cart page:
 * - increase/decrease qty
 * - remove items
 * - totals update without reload
 * - empty cart message
 */

(function () {
  "use strict";

  function escapeHtml(s) {
    return window.UI.escapeHtml(s);
  }

  function render() {
    const listHost = document.getElementById("cartList");
    const summaryHost = document.getElementById("cartSummary");
    if (!listHost || !summaryHost) return;

    const totals = window.Store.getCartTotals();
    const lines = totals.lines;

    if (lines.length === 0) {
      listHost.innerHTML = `
        <div class="empty">
          Your cart is empty. Browse <a class="btn" href="men.html">Men</a> or <a class="btn" href="women.html">Women</a>.
        </div>
      `;
    } else {
      listHost.innerHTML = lines
        .map((l) => {
          return `
            <div class="cart-item" data-key="${escapeHtml(l.key)}">
              <img src="${escapeHtml(l.product.image)}" alt="${escapeHtml(l.product.name)}" />
              <div style="flex:1;">
                <h3>${escapeHtml(l.product.name)}</h3>
                <div class="meta">${escapeHtml(l.product.gender === "men" ? "Men" : "Women")} • ${escapeHtml(
            l.product.category
          )} • Size: <strong>${escapeHtml(l.size)}</strong></div>
                <div class="row">
                  <div class="qty" aria-label="Quantity">
                    <button type="button" data-dec aria-label="Decrease quantity">−</button>
                    <input value="${String(l.qty)}" inputmode="numeric" data-qty aria-label="Quantity value" />
                    <button type="button" data-inc aria-label="Increase quantity">+</button>
                  </div>
                  <div class="spacer"></div>
                  <div class="price">${window.Store.formatMoney(l.lineTotal)}</div>
                  <button class="btn btn-danger" type="button" data-remove>Remove</button>
                </div>
              </div>
            </div>
          `;
        })
        .join("");
    }

    summaryHost.innerHTML = `
      <div class="card card-pad summary">
        <h2 style="margin:0 0 6px; letter-spacing:-.02em;">Order Summary</h2>
        <div class="product-meta" style="margin-bottom:10px;">Totals update instantly.</div>
        <div class="line"><span>Subtotal</span><strong>${window.Store.formatMoney(totals.subtotal)}</strong></div>
        <div class="line"><span>Shipping</span><strong>${window.Store.formatMoney(totals.shipping)}</strong></div>
        <div class="line"><span>Estimated tax</span><strong>${window.Store.formatMoney(totals.tax)}</strong></div>
        <div class="total"><span>Total</span><strong>${window.Store.formatMoney(totals.total)}</strong></div>
        <div style="display:flex; gap:10px; margin-top:14px; flex-wrap:wrap;">
          <a class="btn btn-primary" href="checkout.html" ${lines.length === 0 ? 'aria-disabled="true" tabindex="-1"' : ""}>Checkout</a>
          <button class="btn btn-ghost" type="button" id="clearCart" ${lines.length === 0 ? "disabled" : ""}>Clear cart</button>
        </div>
      </div>
    `;

    // Wire buttons (if cart not empty)
    listHost.querySelectorAll(".cart-item").forEach((row) => {
      const key = row.getAttribute("data-key");
      const qtyInput = row.querySelector("[data-qty]");
      const dec = row.querySelector("[data-dec]");
      const inc = row.querySelector("[data-inc]");
      const rem = row.querySelector("[data-remove]");

      function readQty() {
        const v = Number(qtyInput.value || 1);
        if (!Number.isFinite(v)) return 1;
        return Math.max(1, Math.min(99, v));
      }

      if (dec)
        dec.addEventListener("click", () => window.Store.setLineQty(key, readQty() - 1));
      if (inc)
        inc.addEventListener("click", () => window.Store.setLineQty(key, readQty() + 1));
      if (qtyInput)
        qtyInput.addEventListener("change", () => window.Store.setLineQty(key, readQty()));
      if (rem) rem.addEventListener("click", () => window.Store.removeLine(key));
    });

    const clearBtn = document.getElementById("clearCart");
    if (clearBtn) clearBtn.addEventListener("click", () => window.Store.clearCart());
  }

  document.addEventListener("DOMContentLoaded", render);
  window.addEventListener("cart:changed", render);
})();

