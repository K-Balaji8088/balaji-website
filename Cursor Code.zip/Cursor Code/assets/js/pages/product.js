/**
 * product.js
 * Product details page:
 * - loads product by ?id=
 * - choose size + quantity
 * - add to cart without reload
 */

(function () {
  "use strict";

  function getId() {
    return new URLSearchParams(location.search).get("id") || "";
  }

  function clamp(n, min, max) {
    return Math.max(min, Math.min(max, n));
  }

  document.addEventListener("DOMContentLoaded", () => {
    const id = getId();
    const p = window.Store.getProductById(id);
    const host = document.getElementById("productHost");
    if (!host) return;

    if (!p) {
      host.innerHTML = `
        <div class="empty">
          Product not found. Go back to <a class="btn" href="men.html">Men</a> or <a class="btn" href="women.html">Women</a>.
        </div>
      `;
      return;
    }

    host.innerHTML = `
      <div class="details">
        <div class="details-media">
          <img src="${window.UI.escapeHtml(p.image)}" alt="${window.UI.escapeHtml(p.name)}" />
        </div>
        <div class="card card-pad">
          <div class="chip">${window.UI.escapeHtml(p.gender === "men" ? "Men" : "Women")} • ${window.UI.escapeHtml(p.category)}</div>
          <h1>${window.UI.escapeHtml(p.name)}</h1>
          <p>${window.UI.escapeHtml(p.description)}</p>

          <div class="kvs" aria-label="Product highlights">
            <div class="kv"><strong>Price</strong><span>${window.Store.formatMoney(p.price)}</span></div>
            <div class="kv"><strong>Delivery</strong><span>2–5 business days</span></div>
            <div class="kv"><strong>Returns</strong><span>Free 14-day returns</span></div>
            <div class="kv"><strong>Material</strong><span>Premium blend</span></div>
          </div>

          <div class="section">
            <div class="product-meta" style="margin-bottom:8px;">Select size</div>
            <div id="sizeWrap">
              ${(() => {
                const sizes = ["S", "M", "L", "XL"];
                return `
                  <div class="sizes" role="group" aria-label="Choose size">
                    ${sizes
                      .map(
                        (s, i) => `
                        <button class="size-btn" type="button" data-size="${s}" aria-pressed="${i === 1 ? "true" : "false"}">${s}</button>
                      `
                      )
                      .join("")}
                  </div>
                `;
              })()}
            </div>
          </div>

          <div class="section">
            <div class="qty-row">
              <div class="product-meta">Quantity</div>
              <div class="qty" aria-label="Quantity">
                <button id="qtyMinus" type="button" aria-label="Decrease quantity">−</button>
                <input id="qtyInput" inputmode="numeric" value="1" aria-label="Quantity value" />
                <button id="qtyPlus" type="button" aria-label="Increase quantity">+</button>
              </div>
              <div class="spacer"></div>
              <button class="btn btn-primary" id="addBtn" type="button">Add to Cart</button>
              <a class="btn" href="cart.html">View Cart</a>
            </div>
          </div>
        </div>
      </div>
    `;

    // Wire size buttons
    host.querySelectorAll(".size-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const group = btn.closest(".sizes");
        if (!group) return;
        group.querySelectorAll(".size-btn").forEach((b) => b.setAttribute("aria-pressed", "false"));
        btn.setAttribute("aria-pressed", "true");
      });
    });

    function selectedSize() {
      const pressed = host.querySelector('.size-btn[aria-pressed="true"]');
      return pressed ? pressed.getAttribute("data-size") : "M";
    }

    const qtyInput = document.getElementById("qtyInput");
    const qtyMinus = document.getElementById("qtyMinus");
    const qtyPlus = document.getElementById("qtyPlus");
    const addBtn = document.getElementById("addBtn");

    function readQty() {
      const v = Number(qtyInput.value || 1);
      return clamp(Number.isFinite(v) ? v : 1, 1, 99);
    }
    function writeQty(n) {
      qtyInput.value = String(clamp(n, 1, 99));
    }

    qtyMinus.addEventListener("click", () => writeQty(readQty() - 1));
    qtyPlus.addEventListener("click", () => writeQty(readQty() + 1));
    qtyInput.addEventListener("change", () => writeQty(readQty()));

    addBtn.addEventListener("click", () => {
      try {
        window.Store.addToCart(p.id, selectedSize(), readQty());
        addBtn.textContent = "Added to Cart";
        setTimeout(() => (addBtn.textContent = "Add to Cart"), 1100);
      } catch (e) {
        alert(e && e.message ? e.message : "Unable to add to cart.");
      }
    });
  });
})();

