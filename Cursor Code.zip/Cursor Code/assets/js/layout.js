/**
 * layout.js
 * Shared navbar + footer rendering for all pages.
 * Also keeps the cart badge updated dynamically.
 */

(function () {
  "use strict";

  function $(sel, root) {
    return (root || document).querySelector(sel);
  }

  function escapeHtml(s) {
    return String(s)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function currentPath() {
    const path = (location.pathname || "").split("/").pop() || "index.html";
    // Support people who open ind.html
    if (path.toLowerCase() === "ind.html") return "index.html";
    return path;
  }

  function setCurrent(navRoot) {
    const path = currentPath();
    navRoot.querySelectorAll("[data-nav]").forEach((a) => {
      const target = a.getAttribute("data-nav");
      if (target === path) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });
  }

  function renderHeader() {
    const host = $("#site-header");
    if (!host) return;

    const page = currentPath();
    const q = new URLSearchParams(location.search).get("q") || "";

    host.innerHTML = `
      <a class="skip-link" href="#main">Skip to content</a>
      <header class="nav" role="banner">
        <div class="container">
          <div class="nav-inner">
            <a class="brand" href="index.html" aria-label="Home">
              <span class="brand-badge" aria-hidden="true"></span>
              <span>Violet & Co.</span>
            </a>

            <button class="menu-btn" id="menuBtn" type="button" aria-expanded="false" aria-controls="navLinks">
              Menu
            </button>

            <nav class="nav-links" id="navLinks" aria-label="Primary">
              <a href="index.html" data-nav="index.html">Home</a>
              <a href="men.html" data-nav="men.html">Men</a>
              <a href="women.html" data-nav="women.html">Women</a>
            </nav>

            <div class="nav-right">
              <div class="pill" role="search">
                <span aria-hidden="true">Search</span>
                <input id="navSearch" type="search" placeholder="Shirt, dress, jacket..." value="${escapeHtml(q)}" />
              </div>
              <a class="cart-btn" href="cart.html" aria-label="Cart">
                <span aria-hidden="true">Cart</span>
                <span class="cart-count" id="cartCount">0</span>
              </a>
            </div>
          </div>
        </div>
      </header>
    `;

    const navRoot = host;
    setCurrent(navRoot);

    // Mobile menu
    const menuBtn = $("#menuBtn", navRoot);
    const navLinks = $("#navLinks", navRoot);
    if (menuBtn && navLinks) {
      menuBtn.addEventListener("click", () => {
        const open = navLinks.classList.toggle("open");
        menuBtn.setAttribute("aria-expanded", String(open));
      });
    }

    // Search behavior:
    // - On Home: go to men page with query
    // - On Men/Women pages: keep same page and update ?q=
    const searchInput = $("#navSearch", navRoot);
    if (searchInput) {
      const go = () => {
        const term = (searchInput.value || "").trim();
        const params = new URLSearchParams(location.search);
        if (term) params.set("q", term);
        else params.delete("q");

        if (page === "men.html" || page === "women.html") {
          location.search = params.toString();
        } else if (term) {
          location.href = "men.html?q=" + encodeURIComponent(term);
        } else {
          location.href = "men.html";
        }
      };
      searchInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") go();
      });
    }
  }

  function renderFooter() {
    const host = $("#site-footer");
    if (!host) return;
    host.innerHTML = `
      <footer class="footer" role="contentinfo">
        <div class="container">
          <div class="footer-inner">
            <div>
              <strong>Violet & Co.</strong>
              <div>Modern essentials for Men & Women.</div>
            </div>
            <div>
              <div><strong>Support</strong></div>
              <div>Free returns • Secure checkout • Fast delivery</div>
            </div>
            <div>
              <div><strong>Note</strong></div>
              <div>This is a demo store (no real payments).</div>
            </div>
          </div>
        </div>
      </footer>
    `;
  }

  function updateCartBadge() {
    const el = document.getElementById("cartCount");
    if (!el || !window.Store) return;
    el.textContent = String(window.Store.getCartItemCount());
  }

  document.addEventListener("DOMContentLoaded", () => {
    renderHeader();
    renderFooter();
    updateCartBadge();
  });

  // Listen for cart changes triggered by Store.writeCart
  window.addEventListener("cart:changed", updateCartBadge);
})();

